import { run } from '../functions/command_handler';

describe('Test some function', () => {
  it('Something', () => {
    run([event]);
  });
});
